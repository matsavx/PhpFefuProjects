<?php

namespace App\Controller;

use App\Entity\user;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/user', name: 'user_')]
class UserController extends AbstractController
{
    #[Route(name: 'add', methods: ['POST'])]
    public function registrate(Request $request, UserPasswordHasherInterface $passwordEncoder){
        try{
            $request = $this->transformJsonBody($request);
            $user = new user();
            $user->setUserLogin($request->get('login'));
            $user->setPassword($passwordEncoder->hashPassword(
                $user,
                $request->get('password')
            ));
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            $data = [
                "status"=>Response::HTTP_OK,
                "success"=>"User added successfully"
            ];
            return $this->response($data);
        } catch (Exception){
            $data = [
                "status"=>Response::HTTP_UNPROCESSABLE_ENTITY,
                "errors"=>"Data no valid"
            ];
            return $this->response($data, Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }


    public function transformJsonBody(Request $request): Request
    {
        $data = json_decode($request->getContent(), true);
        if ($data === null) {
            return $request;
        }
        $request->request->replace($data);
        return $request;
    }

    public function response($data, $status = Response::HTTP_OK, $headers = []): JsonResponse
    {
        return new JsonResponse($data, $status, $headers);
    }
}
